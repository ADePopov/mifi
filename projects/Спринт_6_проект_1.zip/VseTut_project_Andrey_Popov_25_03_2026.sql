/* Проект «Разработка витрины и решение ad-hoc задач»
 * Цель проекта: подготовка витрины данных маркетплейса «ВсёТут»
 * и решение четырех ad hoc задач на её основе
 * 
 * Автор: Попов Андрей Денисович
 * Дата: 25.03.2026
*/



/* Часть 1. Разработка витрины данных
 * Напишите ниже запрос для создания витрины данных
*/

WITH region AS	(
	SELECT
		u.region
	FROM ds_ecom.users u
	JOIN ds_ecom.orders o ON u.buyer_id = o.buyer_id 
	WHERE o.order_status IN ('Доставлено', 'Отменено') 
	GROUP BY u.region 
	ORDER BY COUNT(*) DESC
	LIMIT 3
),
main_one AS (
	SELECT 
		u.user_id,
		u.region,
		MIN(o.order_approved_at) first_order_ts, --дата и время первого заказа
		MAX(o.order_approved_at) last_order_ts, --дата и время последнего заказа
		DATE_TRUNC('second', MAX(o.order_approved_at) - MIN(o.order_approved_at)) lifetime, --жизненный цикл клиента, то есть сколько дней прошло между первым и последним заказом
		COUNT(DISTINCT o.order_id) total_orders, --общее количество заказов. buyer_id — идентификатор покупателя, то есть номер 
		COUNT(DISTINCT CASE WHEN order_status = 'Отменено' THEN o.order_id END) num_canceled_orders --количество отменённых заказов
	FROM ds_ecom.users u
	JOIN ds_ecom.orders o ON u.buyer_id = o.buyer_id 
	WHERE u.region IN (SELECT region FROM region) AND order_status IN ('Доставлено', 'Отменено')
	GROUP BY u.user_id,u.region
	),
	reviews_per_orders AS ( -- средняя оценка заказа
	SELECT
		ore.order_id,
		o.buyer_id,
		AVG(CASE WHEN review_score >= 10 THEN review_score/10 ELSE review_score END) reviews_per_orders -- оценка для каждого заказа
	FROM ds_ecom.orders o 
	LEFT JOIN ds_ecom.order_reviews ore ON o.order_id = ore.order_id
	WHERE o.order_status IN ('Доставлено', 'Отменено')
	GROUP BY ore.order_id,
		o.buyer_id
	),
main_sec AS(
	SELECT
		u.user_id,
		u.region,
		ROUND(AVG(reviews_per_orders)::numeric,2) avg_order_rating, --средняя оценка, которую пользователь выставляет своим заказам
		COUNT(DISTINCT CASE WHEN rpo.reviews_per_orders IS NOT NULL THEN rpo.order_id END) num_orders_with_rating --количество заказов, для которых получена оценка с рейтингом.
	FROM ds_ecom.users u
	JOIN ds_ecom.orders o ON u.buyer_id = o.buyer_id
	LEFT JOIN reviews_per_orders rpo ON o.order_id = rpo.order_id
	WHERE u.region IN (SELECT region FROM region) AND order_status IN ('Доставлено', 'Отменено')
	GROUP BY 
		user_id,
		region	
),
order_costs AS(
	SELECT
		o.order_id,
		o.buyer_id,
		SUM(oi.price) + SUM(oi.delivery_cost) AS order_total
	FROM ds_ecom.orders o
	JOIN ds_ecom.order_items oi ON o.order_id = oi.order_id
	WHERE o.order_status = 'Доставлено'
    GROUP BY o.order_id, o.buyer_id
),
main_three AS (
	SELECT
		u.user_id,
		u.region,
		SUM(oc.order_total) total_order_costs, -- суммарная стоимость всех доставленных пользователю заказов.
		COUNT(oc.order_id) AS num_delivered_orders
	FROM ds_ecom.users u
	LEFT JOIN order_costs oc ON u.buyer_id = oc.buyer_id
	WHERE u.region IN (SELECT region FROM region)
	GROUP BY u.user_id,
			u.region
),payment_style AS (
	SELECT 
		op.order_id,
		o.buyer_id,
		MAX(CASE WHEN payment_type = 'промокод' THEN 1 ELSE 0 END) num_orders_with_promo, --промокод да-нет
		MAX(CASE WHEN payment_type = 'денежный перевод' THEN 1 ELSE 0 END) used_money_transfer, -- ден перевод - да-нет
		MAX(CASE WHEN op.payment_installments > 1 THEN 1 ELSE 0 END) used_installments --рассрочка да-нет
	FROM ds_ecom.orders o
	LEFT JOIN ds_ecom.order_payments op ON o.order_id = op.order_id 
	WHERE order_status IN ('Доставлено', 'Отменено')
	GROUP BY op.order_id,
		o.buyer_id	
),
first_type_value_sec AS (
		SELECT
            o.order_id,
            o.buyer_id,
            op.payment_type,
            ROW_NUMBER() OVER (PARTITION BY o.order_id ORDER BY op.payment_sequential) AS rn
        FROM ds_ecom.orders o
        JOIN ds_ecom.order_payments op ON o.order_id = op.order_id
        WHERE o.order_status IN ('Доставлено', 'Отменено')
),
first_type_value AS (
	SELECT 
		order_id,
		buyer_id,
		payment_type AS first_value
	FROM first_type_value_sec
    WHERE rn = 1
),
mmm AS (
	SELECT
		u.user_id,
		u.region,
		COUNT(DISTINCT CASE WHEN used_installments = 1 THEN ps.order_id END) num_installment_orders, -- количество заказов, оплаченных в рассрочку 11
		COUNT(DISTINCT CASE WHEN num_orders_with_promo = 1 THEN ps.order_id END) num_orders_with_promo,-- количество заказов, оплаченных с промокодом 11
		MAX(CASE WHEN ftv.first_value = 'денежный перевод' THEN 1 ELSE 0 END) used_money_transfer, --использовал ли клиент денежный перевод хотя бы один раз в качестве первого типа оплаты ( 1 — использовал, 0 — не использовал).11
		MAX(used_installments) used_installments, -- использовал ли клиент рассрочку хотя бы один раз ( 1 — использовал, 0 — не использовал).11
		MAX(CASE WHEN mo.num_canceled_orders > 0 THEN 1 ELSE 0 END) used_cancel --отменял ли клиент хотя бы один заказ ( 1 — отменял, 0 — не отменял)
	FROM ds_ecom.users u
	LEFT JOIN ds_ecom.orders o ON u.buyer_id = o.buyer_id
		AND o.order_status IN ('Доставлено', 'Отменено')
	LEFT JOIN payment_style ps ON o.order_id = ps.order_id
	LEFT JOIN first_type_value ftv ON o.order_id = ftv.order_id
	LEFT JOIN main_one mo ON u.user_id = mo.user_id AND u.region = mo.region
	WHERE u.region IN (SELECT region FROM region) 
	GROUP BY u.user_id, u.region	
)
SELECT 
	mo.user_id, -- уникальный идентификатор клиента
	mo.region, -- регион, из которого был сделан заказ. Если один и тот же клиент делал заказы из разных регионов, каждый из которых входит в топ-3 по активности, то пользователь может появляться в витрине несколько раз.
	mo.first_order_ts, --дата и время первого заказа.
	mo.last_order_ts, --дата и время последнего заказа.
	mo.lifetime, --жизненный цикл клиента, то есть сколько дней прошло между первым и последним заказом.
	mo.total_orders, --общее количество заказов
	ms.avg_order_rating, --средняя оценка, которую пользователь выставляет своим заказам. 
	num_orders_with_rating, --количество заказов, для которых получена оценка с рейтингом
	num_canceled_orders, --количество отменённых заказов
	ROUND(num_canceled_orders/total_orders::NUMERIC,2) canceled_orders_ratio,--доля отменённых заказов
	total_order_costs, --суммарная стоимость всех доставленных пользователю заказов
	ROUND(total_order_costs/mt.num_delivered_orders::NUMERIC,2) avg_order_cost, --средняя стоимость заказа.
	num_installment_orders,--количество заказов, оплаченных в рассрочку
	num_orders_with_promo, -- количество заказов, оплаченных с промокодом
	used_money_transfer, --— использовал ли клиент денежный перевод хотя бы один раз в качестве первого типа оплаты ( 1 — использовал, 0 — не использовал).
	used_installments, --— использовал ли клиент рассрочку хотя бы один раз ( 1 — использовал, 0 — не использовал).
	used_cancel --— отменял ли клиент хотя бы один заказ ( 1 — отменял, 0 — не отменял).
FROM main_one mo
LEFT JOIN main_sec ms ON mo.user_id = ms.user_id AND mo.region = ms.region
LEFT JOIN main_three mt ON mo.user_id = mt.user_id AND mo.region = mt.region
LEFT JOIN mmm mmm ON mo.user_id = mmm.user_id AND mo.region = mmm.region
ORDER BY mo.user_id, mo.region;


/* Часть 2. Решение ad hoc задач
 * Для каждой задачи напишите отдельный запрос.
 * После каждой задачи оставьте краткий комментарий с выводами по полученным результатам.
*/

/* Задача 1. Сегментация пользователей 
 * Разделите пользователей на группы по количеству совершённых ими заказов.
 * Подсчитайте для каждой группы общее количество пользователей,
 * среднее количество заказов, среднюю стоимость заказа.
 * 
 * Выделите такие сегменты:
 * - 1 заказ — сегмент 1 заказ
 * - от 2 до 5 заказов — сегмент 2-5 заказов
 * - от 6 до 10 заказов — сегмент 6-10 заказов
 * - 11 и более заказов — сегмент 11 и более заказов
*/


WITH segment AS (
SELECT
	user_id,
	total_orders,
	total_order_costs,
	CASE 
		WHEN total_orders = 1 THEN '1 заказ'
		WHEN total_orders BETWEEN 2 AND 5 THEN '2-5 заказов'
		WHEN total_orders BETWEEN 6 AND 10 THEN '6-10 заказов'
		WHEN total_orders >= 11 THEN 'сегмент 11 и более заказов'
	END total_orderss
FROM product_user_features
)
SELECT 
	total_orderss,
	COUNT(user_id) total_users, -- всего пользователей
	ROUND(AVG(total_orders),2) avg_orders, -- среднее количество заказов
	ROUND(SUM(total_order_costs)/SUM(total_orders),2) avg_order_costs -- средняя стоимость заказа
FROM segment
GROUP BY total_orderss
ORDER by 1;

/* Напишите краткий комментарий с выводами по результатам задачи 1.
 * 
*/
/*Большинство людей находится в сегменте "1 заказ" - 60 038. Также у сегмента 1 заказ наибольший средний чек на заказ - 3469,66.
Наименьшее количество людей находятся в сегменте "сегмент 11 и более заказов" - 1. В этом же сегменте наименьший средний чек - 1244,8
Чем больше заказов, тем ниже стоимость заказа.
В сегменте "2-5 заказов" преобладают заказы в 2 шт.*/


/* Задача 2. Ранжирование пользователей 
 * Отсортируйте пользователей, сделавших 3 заказа и более, по убыванию среднего чека покупки.  
 * Выведите 15 пользователей с самым большим средним чеком среди указанной группы.
*/

SELECT 
	user_id,
	total_orders,
	ROUND(total_order_costs/total_orders,2) avg_costs
FROM product_user_features
WHERE total_orders >= 3
ORDER BY avg_costs DESC
LIMIT 15;
	
	-- Напишите ваш запрос тут

/* Напишите краткий комментарий с выводами по результатам задачи 2.
*/
/*Разница между первым и пятнадцатым пользователем по среднему чеку покупки составляет 300% от 6046,67 р. до 18 206,67 р.. 
Всего 5 пользователей имеют средний чек покупки более 10 000 р.*/



/* Задача 3. Статистика по регионам. 
 * Для каждого региона подсчитайте:
 * - общее число клиентов и заказов;
 * - среднюю стоимость одного заказа;
 * - долю заказов, которые были куплены в рассрочку;
 * - долю заказов, которые были куплены с использованием промокодов;
 * - долю пользователей, совершивших отмену заказа хотя бы один раз.
*/

SELECT 
	region,
	COUNT(user_id) total_user_per_region, --общее число клиентов
	SUM(total_orders) total_orders_per_region,--общее число заказов
	ROUND(SUM(total_order_costs)/SUM(total_orders),2) avg_costs,--средняя стоимость заказа
	ROUND(SUM(num_installment_orders)::NUMERIC/SUM(total_orders)*100,2) share_installment_per_region, --доля заказов оплаченных в рассрочку
	ROUND(SUM(num_orders_with_promo)/SUM(total_orders)*100,2) share_promo_per_region, -- доля заказов, оплаченных с промокодом
	ROUND(SUM(used_cancel)::NUMERIC/COUNT(user_id)*100,2) share_canceler_oerder_per_region -- доля отмененных заказов
FROM product_user_features
GROUP BY region
ORDER BY 1;

-- Напишите краткий комментарий с выводами по результатам задачи 3.
/*По общему числу клиентов и общему числу заказов преобладает Москва с отрывом в ~380% от Нобосибирской области и Санкт-Петербурга.
Санкт-Петербург и Новосибирская область примерно идентичны по общему количеству клиентов и общему количесву заказов. 
Средняя стоимость заказа выше в Санкт-Петербурге на ~13% по отношению к Москве и на ~4% по отношению к Новосибирской области. 
В рассрочку меньше всего платят в Москве. 
Чаще всего промокоды используют в Санкт-Петербурге, реже всего в Новосибирской области
Доля отмененных заказов везде примерно едина - ~1%*/

/* Задача 4. Активность пользователей по первому месяцу заказа в 2023 году
 * Разбейте пользователей на группы в зависимости от того, в какой месяц 2023 года они совершили первый заказ.
 * Для каждой группы посчитайте:
 * - общее количество клиентов, число заказов и среднюю стоимость одного заказа;
 * - средний рейтинг заказа;
 * - долю пользователей, использующих денежные переводы при оплате;
 * - среднюю продолжительность активности пользователя.
*/

-- Напишите ваш запрос тут

SELECT
	CAST(DATE_TRUNC('month',first_order_ts) AS date),
	COUNT(user_id) total_users, --общее количество клиентов
	SUM(total_orders) total_orders, --общее число заказов
	ROUND(SUM(total_order_costs)/SUM(total_orders),2) avg_costs, --средняя стоимость заказа
	ROUND(AVG(avg_order_rating),2) avg_rating, --средний рейтинг заказа в разрезе месяца
	ROUND(SUM(used_money_transfer)::numeric/COUNT(user_id)*100,2) share_transfer_money, --доля пользователей использующих денежный перевод при оплате
	DATE_TRUNC('minutes',AVG(lifetime)) avg_lifetime -- средняя продолжительность активности пользователя
FROM product_user_features
WHERE EXTRACT(YEAR FROM first_order_ts) = 2023 
GROUP BY CAST(DATE_TRUNC('month',first_order_ts) AS date)
ORDER BY 1;


/* Напишите краткий комментарий с выводами по результатам задачи 4.
 */
	/*В январе 2023 года зафиксировано минимальное количество юзеров и заказов - 464/500. 
	К Декабрю 2023 года количество юзеров и заказов возросло в 8 раз до - 3583/3702. 3477,37/2686,16
	Максимальное и минимальное средняя стоимость одного заказа за 2023 год варьировалась от 3 477,37 р.(сентябрь) до 2686,16 р.(ферваль). 
	Средний рейтинг заказа весь 2023 год держится около 4. Варьируется от 4,04 до 4,31 
	Доля платящих с помощью кредитных инструментов около 20% весь год. 
	В январе 2023 года зафиксирована наибольшая средняя продолжительность активности пользователя - 12 дней. 
	Наименьшая средняя продолжительность активности пользователя в декабре -  2 дня. 
	Сама продолжительность активности пользователя на протяжении всего года падала без резких скачков.*/ 
